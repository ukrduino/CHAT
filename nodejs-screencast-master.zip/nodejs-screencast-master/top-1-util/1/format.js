var util = require('util');


console.log("My %s %d", "string", 123, {test: "obj"});
