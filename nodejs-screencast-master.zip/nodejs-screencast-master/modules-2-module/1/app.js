var server = require('./server');

server.run();