exports.get = function(req, res) {
  res.render('frontpage');
};