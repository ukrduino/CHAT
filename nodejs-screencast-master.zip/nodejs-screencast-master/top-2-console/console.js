// NO console.debug

console.log("Log"); // = info (out)

console.error("Error"); // = warn (err)

console.trace(); // (err)